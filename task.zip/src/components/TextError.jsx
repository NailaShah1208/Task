import React from 'react'

const TextError = (props) => {
    return (
        <div>
            {props.children}
        </div>
    )
}

export default TextError
